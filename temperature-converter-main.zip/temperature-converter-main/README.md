# ternperature-converter
This repo contains the whole code snippet for the temperature converter . It is a project created using HTML,CSS,JS and this is a similar to calculator which automatically converts the given temperature in other units.
